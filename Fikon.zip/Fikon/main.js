// Fikonspråk translator. Till och från fikonspråk

// Till fikonspråk
function toFikon() {
  let sentence = document.getElementById('text_input').value;
  let vowels = 'aeiyouåäö';
  let fikon = '';
  let fikon1 = '';
  let fikon2 = '';
  let onlyOnce = false;
  let space = ' ';

  for (let i = 0; i < sentence.length; i++) {
    fikon1 += sentence[i];

    if (vowels.includes(sentence[i].toLowerCase()) && onlyOnce === false) {
      fikon2 = fikon1 + 'kon';
      fikon1 = '';
      onlyOnce = true;
    }
    if (space.includes(sentence[i].toLowerCase())) {
      fikon1 = 'fi' + fikon1;
      fikon += fikon1 + fikon2 + ' ';
      onlyOnce = false;
      fikon1 = '';
      fikon2 = '';
    }
  }
  fikon1 = 'fi' + fikon1;
  fikon += fikon1 + ' ' + fikon2;
  document.getElementById('text_input').value = fikon;
}

// Från fikonspråk

function fromFikon() {
  let sentence = document.getElementById('text_input').value;
  let space = ' ';
  let translation = '';
  let fikon1 = '';
  let fikon2 = '';
  let tictoc = false;

  for (let i = 0; i < sentence.length; i++) {
    fikon1 += sentence[i];
    if (
      tictoc &&
      (space.includes(sentence[i].toLowerCase()) || i == sentence.length - 1)
    ) {
      fikon1 = fikon1.replace('kon', ''); //del 2 av ordet
      fikon1 = fikon1.replace(space, '');
      translation += fikon1 + fikon2;
      fikon1 = '';
      tictoc = false;
    } else if (space.includes(sentence[i].toLowerCase())) {
      fikon1 = fikon1.replace('fi', ''); //del 1 av ordet
      fikon2 = fikon1;
      fikon1 = '';
      tictoc = true;
    }
  }
  document.getElementById('text_input').value = translation;
}
